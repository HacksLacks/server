/*

	@copyright: ColdChip

*/
package ru.ColdChip.HTTPServlet;

public class FileData {
	int length;
	byte[] data;
}
package ru.ColdChip.GrowtopiaServer.Player.Structs;

public class PlayerData {
	public String currentWorld = "EXIT";
	public long oid = 0;
	public int netID = 65536;
	public String username = "`6@ColdChip";

	public int x = 0;
	public int y = 0;
}
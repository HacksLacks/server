package ru.ColdChip.GrowtopiaServer.Player.Movement.Structs;

public class MovementData {
	public int packetType;
	public int netID;
	public float x;
	public float y;
	public int characterState;
	public int plantingTree;
	public float XSpeed;
	public float YSpeed;
	public int punchX;
	public int punchY;
}
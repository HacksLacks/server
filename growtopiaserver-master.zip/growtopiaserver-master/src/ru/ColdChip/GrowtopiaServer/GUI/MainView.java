package ru.ColdChip.GrowtopiaServer.GUI;

public class MainView {
	// Constructor to setup the GUI components
	public MainView() {

	}


}
/*

	@copyright: ColdChip

*/
package ru.ColdChip.HTTPServlet;

import java.io.IOException;

public class Route {
	public void handle(Request request, Response response) throws IOException {

	}
}
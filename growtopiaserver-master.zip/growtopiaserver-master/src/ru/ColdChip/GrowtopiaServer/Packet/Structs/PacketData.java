package ru.ColdChip.GrowtopiaServer.Packet.Structs;

public class PacketData {
	public byte[] data;
	public int length;
	public int index;
}